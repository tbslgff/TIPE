import png
import numpy as np
import math


img_data = png.Reader(filename='imgtest.png').asRGBA()
img = [list(row) for row in img_data[2]]


for i in range(999):
    for j in range(999):
        print(i,j, img[i][4*j], img[i][4*j + 1], img[i][4*j + 2])