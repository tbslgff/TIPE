import png
import numpy as np
import math


class color:
    #une couleur est un code RGB(on aurait aussi pu la représenter par un vecteur)
    def __init__(self, R, G, B):
        self.R=R
        self.G=G
        self.B=B

class vec:
    #un vecteur ou un point de l'espace ainsi que les opérations associées
    def __init__(self, x, y, z):
        self.x=x
        self.y=y
        self.z=z
    def __add__(self, other):
        return vec(self.x + other.x, self.y + other.y, self.z + other.z)
    
    def __sub__(self, other):
        return vec(self.x - other.x, self.y - other.y, self.z - other.z)
    
    def norm(self):
        return math.sqrt(self.x**2 + self.y**2 + self.z**2)
    
    def dot(self, other):
        return self.x * other.x + self.y * other.y + self.z * other.z
    
    def __mul__(self, a):
        return vec(self.x * a, self.y * a, self.z * a)
    
    def normalize(self):
        n = self.norm()
        return vec(self.x / n, self.y / n, self.z / n)
    
img_data = png.Reader(filename='left.png').asRGBA()
img = [list(row) for row in img_data[2]]


def same_color(color1, color2):
    #cette fonction renvoie true si deux couleurs sont suffisament proches(false sinon)
    return (abs(color1.R-color2.R)<5 and abs(color1.G-color2.G)<5 and abs(color1.B-color2.B)<5)


def pixel_center (image):
    #cette fonction renvoie les coordonnées du pixel correspondant au centre de la sphère sur une image
    #on part du principe que la sphère apparait sur toutes les images
    #view prend valeur dans [|0,4|]
    i,j = 0,0
    background_color = color(image[0][0], image[0][1], image[0][2])#l'arrière plan de la scène est blanc
    current_pixel = color(image[0][0], image[0][1], image[0][2]) #premier pixel de l'image
    while same_color(current_pixel, background_color):
        if j<999:
            j+=1
        else:
            i+=1
            j=0
        current_pixel=color(image[i][4*j], image[i][4*j + 1], image[i][4*j + 2])#on passe au pixel suivant
    #en sortie de boucle, i et j correspondent aux coordonnées du pixel le plus haut de la sphère
    #toutefois, il est possible que le haut de la sphère soit de la forme:     ___-------___    <------il y a une ligne de pixels à la même hauteur
    #                                                                       __|      ^      |__
    #                                                                                |
    #                                     on veut alors choisir celui du milieu------|
    #
    left_end=j#abcisse du pixel le plus à gauche de la ligne
    #on va maintenant parcourir la même ligne de droite à gauche 
    current_pixel=color(image[i][4*999], image[i][4*999 + 1], image[i][4*999 + 2])
    j=999
    while same_color(current_pixel, background_color):
        j-=1
        current_pixel=color(image[i][4*j], image[i][4*j + 1], image[i][4*j + 2])
    right_end=j#abcisse du pixel le plus à droite de la ligne
    print(left_end,right_end)
    top_pixel=(i, int((left_end + right_end)/2))#pixel du milieu de la ligne
    j=int((left_end + right_end)/2)#on rétablit j à l'abcisse du pixel du milieu
    print(j)
    current_pixel=color(image[999][4*j], image[999][4*j + 1], image[999][4*j + 2])#on établit le pixel courant comme le pixel le plus en bas de l'image et d'abcisse j
    #on monte verticalement pour trouver le pixel le plus bas de la sphère:
    i=999
    while same_color(current_pixel, background_color):
        i-=1
        current_pixel=color(image[i][4*j], image[i][4*j + 1], image[i][4*j + 2])
    #en sortie de boucle, i et j correspondent aux coordonnées du pixel le plus bas de la sphère(on est déjà centré car on est à l'abcisse du centre)
    bot_pixel=(i,j)

    #on peut retourner le pixel au centre de la sphère:
    return (int((top_pixel[0] + bot_pixel[0])/2), int((top_pixel[1] + bot_pixel[1])/2))


print(pixel_center(img))


camera_positions=[vec(0,0,0), vec(5,5,0), vec(-5,5,0), vec(0,10,0), vec(0,5,5)]
 
#on représente la rotation de chacune des caméras par une matrice de rotation:
R0=np.array([[1,0,0],
             [0,0,1],
             [0,-1,0]])

R1=np.array([[0,-1,0],
             [0,0,1],
             [-1,0,0]])

R2=np.array([[0,1,0],
             [0,0,1],
             [1,0,0]])

R3=np.array([[-1,0,0],
             [0,0,1],
             [0,1,0]])

R4=np.array([[1,0,0],
             [0,-1,0],
             [0,0,-1]])

#on rassemble ces matrices dans une liste:
#liste contenant les rotations de chacunes des caméras dans l'ordre front;left;right;back;top:
camera_rotations=[R0, R1, R2, R3, R4]

#cette fonction renvoie la matrice de passage de la base d'une caméra à une autre:
def relative_rotation(i, j):
    #matrice qui donne la rotation de la caméra i vers la caméra j
    print("matrice 1",camera_rotations[j])
    print("matrice 2",np.transpose(camera_rotations[i]))
    print("matrice 1 * matrice 2",np.multiply(camera_rotations[j], np.transpose(camera_rotations[i])))
    return np.matmul(camera_rotations[j], np.transpose(camera_rotations[i]))

#cette fonction renvoie le vecteur de translation d'une matrice à une autre
def translation(i,j):
    return np.array([[camera_positions[j].x - camera_positions[i].x],
                     [camera_positions[j].y - camera_positions[i].y],
                     [camera_positions[j].z - camera_positions[i].z]])

#cette fonction renvoie la représentation matricielle du produit vectoriel avec le vecteur de translation en paramètre
def cross_product_matrix(translation):
    return np.array([[0, -translation[2][0], translation[1][0]],
                     [translation[2][0], 0, -translation[0][0]],
                     [-translation[1][0], translation[0][0], 0]])

#cette fonction renvoie la matrice essentielle i->j
def essential_matrix(i,j):
    t=cross_product_matrix(translation(i,j))
    R=relative_rotation(i,j)
    return np.matmul(R,t)


#test du changement de base

#test de rotation:
tst=np.matmul(np.array([[0,0,1],
             [-1,0,0],
             [0,-1,0]]), np.array([[2],
                                  [-1],
                                  [2]]))

print(tst[0][0],tst[1][0],tst[2][0])



def change_coordinate_system(coordinates, view):
    #cette fonction retourne les coordonnées d'un point dans la base du monde en connaissant ses coordonnées dans la base view(numéro de la camera)
    matrix_coordinates=np.array([coordinates[0]],
                                [coordinates[1]],
                                [coordinates[2]])
    #rotation des coordonnées dans l'orientation de la nouvelle base
    rotated_coordinates=np.matmul(camera_rotations[view], matrix_coordinates)
    translation_matrix=np.array([camera_positions[view].x()],
                                [camera_positions[view].y()],
                                [camera_positions[view].z()])
    #translation
    new_coordinates_matrix=rotated_coordinates + translation_matrix
    new_coordinates=(new_coordinates_matrix[0][0], new_coordinates_matrix[1][0], new_coordinates_matrix[2][0])
    return new_coordinates