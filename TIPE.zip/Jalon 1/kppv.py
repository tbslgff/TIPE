import numpy as np
import cv2 as cv
import glob
import os

database_filenames = glob.glob(os.path.join("database/spheres", "*.png"))
database_size = len(database_filenames)

imagetest = "tst.png"

def dist(img1_filename: str, img2_filename: str):
    img1 = cv.resize(cv.imread(img1_filename), (256, 256))
    img2 = cv.resize(cv.imread(img2_filename), (256, 256))

    # différence absolue sur chaque BGR de chaque pixel
    diff = np.abs(img1.astype(np.int32) - img2.astype(np.int32))
    return np.sum(diff)

distances = [(filename, dist(filename, imagetest)) for filename in database_filenames]
distances = sorted(distances, key=lambda x: x[1])

for i in range(5):
    print("voisin le plus proche ", i+1, ": ", distances[i][0])