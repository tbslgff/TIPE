# -*- coding: utf-8 -*-

#ce programme détermine la position dans l'espace, la couleur et le rayon d'une sphère dans une scène 3d
#à partir de 5 images des points de vue: front;left;right;back;top de la scène
#l'arrière plan de la scène est blanc.

import png #librairie pour lire et écrire des images png
import math
import numpy as np
#---------------------------représente les 5 images format png en 5 listes python-------------------------------------#

#chaque image est de résolution 1000x1000 pixels.
#la liste python représentant une image est donc de la forme: 
# [[R,G,B, R,G,B, ...., R,G,B],[R,G,B, R,G,B, ...., R,G,B], ..., [R,G,B, R,G,B, ...., R,G,B]]
#  1e ligne de 1000 pixels          2e ligne de 1000 pixels          1000e ligne de 1000 pixels

image_front_data = png.Reader(filename='front.png').asRGBA()
#image_front_data contient dans un tuple les dimensions de l'image et d'autres métadonnées, ainsi que les pixels.
#les pixels sont en 3e position dans le tuple, on les extrait pour les stocker dans une liste:

image_front = [list(row) for row in image_front_data[2]]
#liste contenant les pixels de l'image

#on fait pareil pour les 4 autres images:
image_left_data = png.Reader(filename='left.png').asRGBA()
image_left = [list(row) for row in image_left_data[2]]

image_right_data = png.Reader(filename='right.png').asRGBA()
image_right = [list(row) for row in image_right_data[2]]

image_back_data = png.Reader(filename='back.png').asRGBA()
image_back = [list(row) for row in image_back_data[2]]

image_top_data = png.Reader(filename='top.png').asRGBA()
image_top = [list(row) for row in image_top_data[2]]


povs=[image_front, image_left, image_right, image_back, image_top]
#on rassemble les 5 images dans une liste pour pouvoir y accéder dans la suite du programme avec les indices de 0 à 4

#---------------------------------------------------------------------------------------------------------------------#

#-------------------------------------classes utilisées dans le programme---------------------------------------------#

class color:
    #une couleur est un code RGB(on aurait aussi pu la représenter par un vecteur)
    def __init__(self, R, G, B):
        self.R=R
        self.G=G
        self.B=B

class vec:
    #un vecteur ou un point de l'espace ainsi que les opérations associées
    def __init__(self, x, y, z):
        self.x=x
        self.y=y
        self.z=z
    def __add__(self, other):
        return vec(self.x + other.x, self.y + other.y, self.z + other.z)
    
    def __sub__(self, other):
        return vec(self.x - other.x, self.y - other.y, self.z - other.z)
    
    def norm(self):
        return math.sqrt(self.x**2 + self.y**2 + self.z**2)
    
    def dot(self, other):
        return self.x * other.x + self.y * other.y + self.z * other.z
    
    def __mul__(self, a):
        return vec(self.x * a, self.y * a, self.z * a)
    
    def normalize(self):
        n = self.norm()
        return vec(self.x / n, self.y / n, self.z / n)

#---------------------------------------------------------------------------------------------------------------------#

#-----------------------trouve dans chaque image le pixel correspondant au centre de la sphère------------------------#

def same_color(color1, color2):
    #cette fonction renvoie true si deux couleurs sont suffisament proches(false sinon)
    return (abs(color1.R-color2.R)<5 and (color1.G-color2.G)<5 and (color1.B-color2.B)<5)

def pixel_center (view):
    #cette fonction renvoie les coordonnées du pixel correspondant au centre de la sphère sur une image
    #on part du principe que la sphère apparait sur toutes les images
    #view prend valeur dans [|0,4|]
    i,j = 0,0
    background_color = color(povs[view][0][0], povs[view][0][1], povs[view][0][2])#l'arrière plan de la scène est blanc
    current_pixel = background_color #premier pixel de l'image
    while same_color(current_pixel, background_color):
        if i<999:
            i+=1
        else:
            j+=1
            i=0
        current_pixel=color(povs[view][j][4*i], povs[view][j][4*i + 1], povs[view][j][4*i + 2])#on passe au pixel suivant
    #en sortie de boucle, i et j correspondent aux coordonnées du pixel le plus haut de la sphère
    #toutefois, il est possible que le haut de la sphère soit de la forme:     ___-------___    <------il y a une ligne de pixels à la même hauteur
    #                                                                       __|      ^      |__
    #                                                                                |
    #                                     on veut alors choisir celui du milieu------|
    #
    left_end=i#abcisse du pixel le plus à gauche de la ligne
    #on va maintenant parcourir la même ligne de droite à gauche 
    current_pixel=color(povs[view][j][4*999], povs[view][j][4*999 + 1], povs[view][j][4*999 + 2])
    i=999
    while same_color(current_pixel, background_color):
        i-=1
        current_pixel=color(povs[view][j][4*i], povs[view][j][4*i + 1], povs[view][j][4*i + 2])
    right_end=i#abcisse du pixel le plus à droite de la ligne
    top_pixel=(int((left_end + right_end)/2),j)#pixel du milieu de la ligne
    i=int((left_end + right_end)/2)#on rétablit i à l'abcisse du pixel du milieu
    current_pixel=color(povs[view][999][4*i], povs[view][999][4*i + 1], povs[view][999][4*i + 2])#on établit le pixel courant comme le pixel le plus en bas de l'image et d'abcisse i
    #on monte verticalement pour trouver le pixel le plus bas de la sphère:
    j=999
    while same_color(current_pixel, background_color):
        j-=1
        current_pixel=color(povs[view][j][4*i], povs[view][j][4*i + 1], povs[view][j][4*i + 2])
    #en sortie de boucle, i et j correspondent aux coordonnées du pixel le plus bas de la sphère(on est déjà centré car on est à l'abcisse du centre)
    bot_pixel=(i,j)

    #on peut retourner le pixel au centre de la sphère:
    return (int((top_pixel[0] + bot_pixel[0])/2), int((top_pixel[1] + bot_pixel[1])/2))




#---------------------------------------------------------------------------------------------------------------------#


#------------------------------------------définit les caméras------------------------------------------------------#

#pour trianguler la position de la sphère :(https://docs.google.com/document/d/1NwimK9_Qu0JO_8vAYp2ItyoEuJC1fj4NcVTAHfEcRWE/edit?tab=t.0#bookmark=id.h4xyw99cs0zr)
#on a besoin de représenter les caméras dans l'espace:

#on prend l'origine du repère aux coordonnées de la caméra front
#l'axe x est dirigé vers la droite de la camera front
#l'axe y est dirigé vers le milieu du champ de vision de la caméra front
#l'axe z est dirigé vers le dessus de la caméra front

#chaque caméra possède sa propre base

#liste contenant les positions de chacune des caméras dans l'ordre front;left;right;back;top:
camera_positions=[vec(0,0,0), vec(-10,10,0), vec(10,10,0), vec(0,20,0), vec(0,10,10)]

#on représente la rotation de chacune des caméras par une matrice de rotation:
R0=np.array([[1,0,0],
             [0,0,1],
             [0,-1,0]])

R1=np.array([[0,0,1],
             [-1,0,0],
             [0,-1,0]])

R2=np.array([[0,0,-1],
             [1,0,0],
             [0,-1,0]])

R3=np.array([[-1,0,0],
             [0,0,-1],
             [0,-1,0]])

R4=np.array([[1,0,0],
             [0,-1,0],
             [0,0,-1]])

#on rassemble ces matrices dans une liste:
#liste contenant les rotations de chacunes des caméras dans l'ordre front;left;right;back;top:
camera_rotations=[R0, R1, R2, R3, R4]

#cette fonction renvoie la rotation d'une base d'une caméra à une autre:
def relative_rotation(i, j):
    #matrice qui donne la rotation de la caméra i vers la caméra j
    print("matrice 1",camera_rotations[j])
    print("matrice 2",np.transpose(camera_rotations[i]))
    print("matrice 1 * matrice 2",np.multiply(camera_rotations[j], np.transpose(camera_rotations[i])))
    return np.matmul(camera_rotations[j], np.transpose(camera_rotations[i]))

#cette fonction renvoie le vecteur de translation d'une matrice à une autre
def translation(i,j):
    return np.array([[camera_positions[j].x - camera_positions[i].x],
                     [camera_positions[j].y - camera_positions[i].y],
                     [camera_positions[j].z - camera_positions[i].z]])

#cette fonction renvoie la représentation matricielle du produit vectoriel avec le vecteur de translation en paramètre
def cross_product_matrix(translation):
    return np.array([[0, -translation[2][0], translation[1][0]],
                     [translation[2][0], 0, -translation[0][0]],
                     [-translation[1][0], translation[0][0], 0]])

#la matrice essentielle permet de passer de la base d'une caméra à une autre (une matrice essentielle par paire de caméras)
#si xi est la matrice colonne qui représente les coordonnées d'un point dans la base d'une caméra i
#si xj est la matrice colonne qui représente les coordonnées d'un point dans la base d'une caméra j
#et que E est la matrice essentielle pour passer de la caméra i à la caméra j, alors
# transposée(xj) * E * xi = 0

#cette fonction renvoie la matrice essentielle i->j
def essential_matrix(i,j):
    t=cross_product_matrix(translation(i,j))
    R=relative_rotation(i,j)
    return np.matmul(R,t)



#---------------------------------------------------------------------------------------------------------------------#


#--------------------------------triangule les coordonnées du centre de la sphère-------------------------------------#


#les dimensions du viewport sont 36mm*36mm

def pixel_to_coordinates(pixel_list):
    #cette fonction renvoie les coordonnées des pixel des centres de la sphère dans la base de sa caméra
    coordinates=[]
    for i in range(5):
        #x et y sont les coordonnées d'un pixel dans le repère de l'image
        #(origine à (0,0) et l'axe x est orienté vers la droite, l'axe y vers le bas)
        x=pixel_list[i][0]*((36e-3)/1000)
        y=pixel_list[i][1]*((36e-3)/1000)
        coordinates.append((round((x-(36e-3)/2),7),round((y-(36e-3)/2),7),100e-3))
    return coordinates


def change_coordinate_system(coordinates, view):
    #cette fonction retourne les coordonnées d'un point dans la base du monde en connaissant ses coordonnées dans la base view(numéro de la camera)
    matrix_coordinates=np.array([[coordinates[0]],
                                [coordinates[1]],
                                [coordinates[2]]])
    #rotation des coordonnées dans l'orientation de la nouvelle base
    rotated_coordinates=np.matmul(camera_rotations[view], matrix_coordinates)
    translation_matrix=np.array([[camera_positions[view].x],
                                [camera_positions[view].y],
                                [camera_positions[view].z]])
    #translation
    new_coordinates_matrix=rotated_coordinates + translation_matrix
    new_coordinates=(round(float(new_coordinates_matrix[0][0]),7), round(float(new_coordinates_matrix[1][0]),7), round(float(new_coordinates_matrix[2][0]),7))
    return new_coordinates





#créons une liste qui contient les coordonnées du centre de la sphère sur chacune des images:
center_pixels=[pixel_center(i) for i in range(5)]

#créons une liste qui contient les coordonnées des pixels des centres de la sphère dans la base de sa caméra:
pixel_coordinates=pixel_to_coordinates(center_pixels)

#créons une liste qui contient les coordonnées des pixels des centres de la sphère dans la base globale:
pixel_center_global_coordinates=[change_coordinate_system(pixel_coordinates[i],i) for i in range(5)]

#on affiche
for i in range(5):
    print(center_pixels[i],
          ", coordonnées dans la base de sa caméra: ", pixel_coordinates[i], 
          "coordonnées dans la base du monde: ", pixel_center_global_coordinates[i], "\n")

#on calcule les vecteurs normalisés pointant vers le centre de la sphère pour chaque caméra:
def compute_direction(view, point):
    normed=(vec(point[view][0]-camera_positions[view].x, point[view][1]-camera_positions[view].y, point[view][2]-camera_positions[view].z)).normalize()
    return [normed.x, normed.y, normed.z]

#on stocke les vecteurs normaux dans une liste:
directions=[compute_direction(i, pixel_center_global_coordinates) for i in range(5)]

# Fonction pour générer deux vecteurs orthogonaux à di
def orthogonal_vectors(d):
    # d est normalisé
    # Trouver un vecteur non colinéaire à d
    if abs(d[0]) > abs(d[1]):
        v = np.array([-d[1], d[0], 0])
    else:
        v = np.array([0, -d[2], d[1]])
    u = np.cross(d, v)  # Premier vecteur orthogonal
    v = np.cross(d, u)  # Deuxième vecteur orthogonal
    # Normalise les vecteurs
    u = u / np.linalg.norm(u)
    v = v / np.linalg.norm(v)
    return u, v

# Fonction pour trianguler le centre de la sphère
def triangulate_center(i, j):
    # Ignorer image_coordinates1, image_coordinates2, i, j, E, R car nous utilisons toutes les caméras
    # et les vecteurs directeurs dans la base globale
    
    # Construire un système linéaire A * X = b
    A = np.zeros((10, 3))  # 5 caméras * 2 équations par caméra
    b = np.zeros(10)
    
    for i in range(5):
        C = np.array([camera_positions[i].x, camera_positions[i].y, camera_positions[i].z])
        d = np.array(directions[i])
        u, v = orthogonal_vectors(d)
        # Ajouter les équations: (X - C) . u = 0 et (X - C) . v = 0
        A[2*i] = u
        A[2*i + 1] = v
        b[2*i] = np.dot(u, C)
        b[2*i + 1] = np.dot(v, C)
    
    # Résoudre le système linéaire par moindres carrés avec numpy
    X, _, _, _ = np.linalg.lstsq(A, b, rcond=None)
    
    # Position 3D estimée
    return vec(X[0], X[1], X[2])


center = triangulate_center(0, 1)
print("Position 3D du centre de la sphère :", (center.x, center.y, center.z))