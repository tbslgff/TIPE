import numpy as np
import math
import png, colorsys

class color:
    #une couleur est un code RGB(on aurait aussi pu la représenter par un vecteur)
    def __init__(self, R, G, B):
        self.R=R
        self.G=G
        self.B=B

def has_alpha(filename: str) -> bool:
    """
    Vérifie si l'image PNG a un canal alpha.
    Retourne True si oui, False sinon.
    """
    reader = png.Reader(filename=filename)
    _, _, _, info = reader.read()
    return info.get("alpha", False)

# Exemple d'utilisation
if __name__ == "__main__":
    fichier = "left.png"
    if has_alpha(fichier):
        print(f"{fichier} possède un canal alpha (transparence).")
    else:
        print(f"{fichier} ne possède PAS de canal alpha.")


# Lecture de l'image
reader = png.Reader(filename="right.png")
w, h, pixels, info = reader.asRGBA()  # on force RGBA pour uniformiser

# Conversion ligne par ligne
hsl_pixels = []
for row in pixels:
    # chaque pixel = (R, G, B, A)
    hsl_row = []
    for i in range(0, len(row), 4):
        r, g, b, a = row[i:i+4]
        
        # normaliser en [0,1]
        r, g, b = r/255.0, g/255.0, b/255.0
        h, l, s = colorsys.rgb_to_hls(r, g, b)  # ⚠️ attention: c'est HLS dans colorsys, pas HSL

        # si tu veux stocker en degrés et pourcentage :
        h = int(h*360)
        s = int(s*100)
        l = int(l*100)

        hsl_row.append((h, s, l, a))
    hsl_pixels.append(hsl_row)


def same_color(color1, color2):
    #cette fonction renvoie true si deux couleurs sont suffisament proches(false sinon)
    return (abs(color1.R-color2.R)<5 and abs(color1.G-color2.G)<5 and abs(color1.B-color2.B)<5)

def same_hue(hue1, hue2):
    return (abs(hue1-hue2))


def pixel_center (image):
    #cette fonction renvoie les coordonnées du pixel correspondant au centre de la sphère sur une image
    #on part du principe que la sphère apparait sur toutes les images
    #view prend valeur dans [|0,4|]
    i,j = 0,0
    background_hue = image[0][0][0]#l'arrière plan de la scène est blanc
    current_pixel = image[0][0][0]#premier pixel de l'image
    while same_hue(current_pixel, background_hue):
        if j<999:
            j+=1
        else:
            i+=1
            j=0
        current_pixel=image[i][j][0]#on passe au pixel suivant
    #en sortie de boucle, i et j correspondent aux coordonnées du pixel le plus haut de la sphère
    #toutefois, il est possible que le haut de la sphère soit de la forme:     ___-------___    <------il y a une ligne de pixels à la même hauteur
    #                                                                       __|      ^      |__
    #                                                                                |
    #                                     on veut alors choisir celui du milieu------|
    #
    left_end=j#abcisse du pixel le plus à gauche de la ligne
    sphere_color=current_pixel
    while same_hue(current_pixel, sphere_color):
        j+=1
        current_pixel=image[i][j][0]
    j-=1
    right_end=j#abcisse du pixel le plus à droite de la ligne
    top_pixel=(i, int((left_end + right_end)/2))#pixel du milieu de la ligne
    j=int((left_end + right_end)/2)#on rétablit j à l'abcisse du pixel du milieu
    current_pixel=image[i][j][0]#on rétablit le pixel courant
    #on descend verticalement pour trouver le pixel le plus bas de la sphère:
    while same_hue(current_pixel, sphere_color):
        i+=1
        current_pixel=image[i][j][0]
    #en sortie de boucle, i et j correspondent aux coordonnées du pixel le plus bas de la sphère(on est déjà centré car on est descendu verticalement)
    bot_pixel=(i,j)

    #on peut retourner le pixel au centre de la sphère:
    return (int((top_pixel[0] + bot_pixel[0])/2), int((top_pixel[1] + bot_pixel[1])/2))

for i in range(999):
    for j in range (999):
        if(hsl_pixels[i][j][1]>1):
            print(hsl_pixels[i][j])

print(pixel_center(hsl_pixels))